package com.systracker

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class ExpenseControllerSpec extends Specification implements ControllerUnitTest<ExpenseController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
