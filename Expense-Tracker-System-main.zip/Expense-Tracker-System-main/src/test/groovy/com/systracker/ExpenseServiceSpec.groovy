package com.systracker

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ExpenseServiceSpec extends Specification implements ServiceUnitTest<ExpenseService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
