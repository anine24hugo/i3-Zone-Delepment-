package com.systracker

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class CurrencyConverterServiceSpec extends Specification implements ServiceUnitTest<CurrencyConverterService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
